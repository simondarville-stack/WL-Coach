-- Add variation_note to planned_exercises
ALTER TABLE planned_exercises
  ADD COLUMN IF NOT EXISTS variation_note text DEFAULT NULL;
